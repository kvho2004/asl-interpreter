# MediaPipe HandLandmarker Task for web

A Pen created on CodePen.

Original URL: [https://codepen.io/kvho2004/pen/vEKxXVL](https://codepen.io/kvho2004/pen/vEKxXVL).

